//Este archivo debe calcular el factorial de 10 utilizando un bucle while
var i = 1;
var factorial = 1;
while(i < 11){
    factorial = i*factorial;
    i++;
}
console.log(factorial);