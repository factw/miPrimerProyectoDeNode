//Este archivo debe calcular el factorial de 10 utilizando un solo bucle for
var factorial = 1;
for(let i = 1; i < 11; i++){         
    factorial = i*factorial;
}
console.log(factorial);
